
# Deadlines Manager for Windows

Questa è l'app Flutter per gestire scadenze, priorità e completamenti, con storico salvato in locale.

## Come generare l'eseguibile `.exe`

1. Crea un nuovo repository GitHub.
2. Carica tutto il contenuto di questa cartella.
3. Vai su `Actions`, abilita i workflow e avvia la build `Build Windows EXE`.
4. Scarica il file `.exe` compilato dalla sezione Artifact.
